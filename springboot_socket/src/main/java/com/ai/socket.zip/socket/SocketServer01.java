package com.ai.socket;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;


//@Component
public class SocketServer01 {

    private static final Logger log = LoggerFactory.getLogger(SocketServer01.class);

    @PostConstruct
    public void start() {
        new Thread(this::listen).start();
    }

    private void listen() {
        try (ServerSocket serverSocket = new ServerSocket(12001)) {
            log.info("TCP Socket 服务已启动，端口：12001");
            while (!Thread.currentThread().isInterrupted()) {
                Socket client = serverSocket.accept();
                new Thread(() -> handle(client)).start();
            }
        } catch (IOException e) {
            log.error("Socket 服务异常", e);
        }
    }

    private void handle(Socket socket) {
        try (socket;
             InputStream in = socket.getInputStream();
             OutputStream out = socket.getOutputStream()) {

            byte[] buffer = new byte[1024];
            int len;
            while ((len = in.read(buffer)) != -1) {
                String msg = new String(buffer, 0, len, StandardCharsets.UTF_8);
                log.info("收到客户端消息：{}", msg);

                String response = "OK: " + msg;
                out.write(response.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
        } catch (IOException e) {
            log.error("处理客户端连接异常", e);
        }
    }
}
